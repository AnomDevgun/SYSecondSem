#include <stdio.h>

int main(int args, char * argv[])
{
	printf("Helllo World");
	printf("%s",argv[1]);
 	return 0;
}
