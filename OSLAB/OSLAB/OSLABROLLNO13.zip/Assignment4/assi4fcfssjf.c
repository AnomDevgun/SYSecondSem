/*
ANOM DEVGUN
ROLL NO 13
SY A1
*/


#include <stdio.h>
#include <stdlib.h>

struct node
{
	int pid; //Process ID
	int at;  //Arrival Time
	int bt;  //Burst Time
	int ct;  //Completeion time
	int tt;  //turnaround
	int wt;  //wait time
	struct node *next;
} *head = NULL, *next = NULL;


void fcfs(int num)								//FIRST COME FIRST SERVE
{
	int r;
	float mtt = 0.0,mwt=0.0;
	int t=0;
	struct node *tem,*current = malloc(sizeof(struct node));
	tem = NULL;
	current = head;
	if (head == NULL)
		{
		printf("No Processes\n");
		}	
	else
	{
		while(current!= NULL){
			tem = current->next;
				while (tem!= NULL)
				{
					if ((current->at) > (tem->at))
					{
						r = tem->pid;
						tem->pid = current->pid;
						current->pid = r;
						r = tem->at;
						tem->at = current->at;
						current->at = r;
						r = tem->bt;
						tem->bt = current->bt;
						current->bt = r;
					}
				tem=tem->next;
				}
				current = current->next;
	}
		tem = head;
		while (tem != NULL)
		{
				if(t<tem->at){
					while(t!=tem->at){
					t++;
					}
					}
					tem->ct = t+(tem->bt);						//CALCULATING TT,CT,WT
					t = t+(tem->bt);
					tem->tt = (tem->ct)-(tem->at);
					tem->wt = (tem->tt)-(tem->bt);
					mtt += tem->tt;
					mwt += tem->wt;
					tem = tem->next;
		}
		tem = head;
		while(tem!=NULL)
		{
			if(tem->next == NULL)
						printf("%d", tem->pid);
					else{
						printf("%d->", tem->pid);
						if((((tem->next)->at)>(tem->at+tem->bt))&&((tem->next)->at > tem->ct))
						{
						int k;
						int li = (((tem->next)->at)-(tem->at+tem->bt));
						if(li!=0)
						{
						for(k=1;k<=li;k++)
						{
						printf("idle->");
						}
						}
						}
					}
					tem = tem->next;
		}
		printf("\n");
		printf("\n");
	    printf("Mean turnaround time : %f\n",(mtt/num));
	    printf("Mean wait time : %f\n",(mwt/num));
	}
}


void sjf(int num)										//SHORTEST JOB FIRST
{
	int t=0;
	float mwt=0.0,mtt=0.0;
	int r;
	struct node *tem,*current = malloc(sizeof(struct node));
	tem = NULL;
	current = head;
	if (head == NULL)
		{
		printf("No Processes\n");
		}	
	else
	{
		while(current!= NULL){
		tem = current->next;
			while (tem!= NULL)
			{
				if ((current->at) > (tem->at))
				{
					r = tem->pid;
					tem->pid = current->pid;
					current->pid = r;
					r = tem->at;
					tem->at = current->at;
					current->at = r;
					r = tem->bt;
					tem->bt = current->bt;
					current->bt = r;
				}
			tem=tem->next;
			}
			current = current->next;
		}
		current = head;		
		current = current->next;
		while(current!= NULL){				//SECOND SWAP ACCORDING TO MIN BURST TIME
				tem = current->next;
					while (tem!= NULL)
					{
						if ((current->bt) > (tem->bt))
						{
							r = tem->pid;
							tem->pid = current->pid;
							current->pid = r;
							r = tem->at;
							tem->at = current->at;
							current->at = r;
							r = tem->bt;
							tem->bt = current->bt;
							current->bt = r;
						}
					tem=tem->next;
					}
					current = current->next;
		}
			tem = head;
			while (tem != NULL)
			{
						if(t<tem->at){
							while(t!=tem->at){
								t++;
							}
				}
				tem->ct = t + (tem->bt);
				t = t + tem->bt;
				tem->tt = (tem->ct) - (tem->at);
				tem->wt = (tem->tt) - (tem->bt);
				mtt += tem->tt;
				mwt += tem->wt;
				tem = tem->next;
			}
			tem = head;
					while(tem!=NULL)
		{
			if(tem->next == NULL)
						printf("%d", tem->pid);
					else{
						printf("%d->", tem->pid);
						if((((tem->next)->at)>(tem->at+tem->bt))&&((tem->next)->at > tem->ct))
						{
						int k;
						int li = (((tem->next)->at)-(tem->at+tem->bt));
						if(li!=0)
						{
						for(k=1;k<=li;k++)
						{
						printf("idle->");
						}
						}
						}
					}
					tem = tem->next;
		}
			printf("\n");
			printf("\n");
			printf("Mean turnaround time : %f\n",(mtt/num));
			printf("Mean wait time : %f\n",(mwt/num));
	}
}

int main()											//MAIN 
{
	unsigned int n, i, ch;
	printf("How many processes would you like to schedule?\n");
	scanf("%u", &n);
	for (i = 0; i < n; i++)
	{
		struct node *nn = malloc(sizeof(struct node));
		struct node *temp = malloc(sizeof(struct node));
		if (head == NULL)
		{
			printf("Enter the process id: \n");
			scanf("%d", &nn->pid);
			printf("Enter the arrival time: \n");				//INPUT PROCESSES
			scanf("%d", &nn->at);
			printf("Enter the burst time: \n");
			scanf("%d", &nn->bt);
			head = nn;
		}
		else
		{
			temp = head;
			while (temp->next != NULL)
			{
				temp = temp->next;
			}
			printf("Enter the process id: \n");
			scanf("%d", &nn->pid);
			printf("Enter the arrival time: \n");
			scanf("%d", &nn->at);
			printf("Enter the burst time: \n");
			scanf("%d", &nn->bt);
			temp->next = nn;
		}
	}
	printf("Process\tArrival time\tBurst time\n");
	struct node *t = malloc(sizeof(struct node));
	t = head;
	for (i = 0; i < n; i++)
	{
		while (t != NULL)
		{
			printf("%d\t", t->pid);								//PRINT PROCESS TABLE
			printf("%d\t", t->at);
			printf("%d\t", t->bt);
			printf("\n");
			t = t->next;
		}
	}

	printf("Please enter your choice: \n");				//CHOOSE METHOD OF SCHEDULING
	printf("1)FCFS\n");
	printf("2)SJF\n");
	printf("3)Round Robbin\n");
	printf("4)Exit\n");
	scanf("%u", &ch);
	printf("\n");

	while (ch!=4)
	{
		switch (ch)
		{
			case 1:
				printf("You Have Picked FCFS\n");
				fcfs(n);
				printf("\n");
				t = head;
					printf("Pid\tAT\tBT\tCT\tTT\tWT\n");
					for ( i = 0; i < n; i++)
					{
						while (t != NULL)
						{
							printf("%d\t", t->pid);
							printf("%d\t", t->at);
							printf("%d\t", t->bt);
							printf("%d\t",t->ct);
							printf("%d\t",t->tt);
							printf("%d\t",t->wt);
							printf("\n");
							t = t->next;
						}
					}
				break;
			case 2:
				printf("You Have Picked SJF\n");
				sjf(n);
				t = head;
				printf("Pid\tAT\tBT\tCT\tTT\tWT\n");
					for ( i = 0; i < n; i++)
					{
						while (t != NULL)
						{
							printf("%d\t", t->pid);
							printf("%d\t", t->at);
							printf("%d\t", t->bt);
							printf("%d\t",t->ct);
							printf("%d\t",t->tt);
							printf("%d\t",t->wt);
							printf("\n");
							t = t->next;
						}
					}
								printf("\n");
				break;
			case 3:
				printf("You have Picked Round Robbin\n");
				//rr();
				printf("\n");
				break;
			case 4:
				printf("Goodbye!\n");
				break;
			default:
				printf("Incorrect Choice.\n");
		}

		printf("Please enter your choice: \n");
		printf("1)FCFS\n");
		printf("2)SJF\n");
		printf("3)Round Robbin\n");
		printf("4)Exit\n");
		scanf("%u", &ch);
		printf("\n");
	}
	while(head->next!=NULL)
	{
	struct node *temp = malloc(sizeof(struct node));
	temp = head->next;
	head = head->next;
	free(temp);
	}
	free(head);
	return 0;
}
