zenity --list --checklist --column "SELECT" --column "OPERATION" FALSE ADD FALSE LIST FALSE FIND FALSE DELETE FALSE UPDATE FALSE EXIT --width=10 --height=300

